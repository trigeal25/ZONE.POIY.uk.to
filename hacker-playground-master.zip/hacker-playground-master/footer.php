
<div class="row";>
<div class="col-md-12">
<hr>
<center>
<a href="about.php"> ABOUT ME</a>
<br>
Powered by <a href='http://hacker-playground.com'>hacker-playground</a>
<br>

<?php

mysql_close($konek);



?>

</center>
</div>

</div>

</html>





