<?php
include 'header.php' ;


?>


<h1>404</h1>
code before hack !