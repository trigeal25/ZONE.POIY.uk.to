# hacker-playground
platform for simple chat, forum, file sharing, riddle leaderboard, and many more.

CURRENT FEATURE
* chat
* deface mirror
* file sharing (just link share)
* password (md5, base64, sha1 encrypt)
* rank
* riddle


Welcome to the hacker-playground wiki!

# About
this is the platform for simple chat, forum, file sharing and riddle leaderboard use simple php code. You can download the code and install it manually on your own web server.

# Requirement
webserver running apache, mysql  and php 5 (php7 deprecated).

# Install
Just download the soce and upload to your public html, and import the database.sql

# Configuration
edit the setting.php and configure the database like host, username, password and database name

# Demo
visit [hacker-playground](http://hacker-playground.com)

# Help
visit [hacker-playground](http://hacker-playground.com)

# Screenshot
![home](https://1.bp.blogspot.com/-Fke_Uhd7Zew/WQaoWw_kP7I/AAAAAAAAAis/kTxdvWAidyARCdLJcmk79YcN2vDRAZNwwCLcB/s1600/1.jpg)

![search](https://4.bp.blogspot.com/-ATURQfVe4TY/WQaoXIBBvUI/AAAAAAAAAi0/41QEfqLIc0owU73iblt70b9LmaKYdbPAwCLcB/s1600/3.jpg)

![rank](https://2.bp.blogspot.com/-hAxvjDT7BI4/WQaoW_kgpQI/AAAAAAAAAiw/rOuwgJurcnEGyogBXXIOSEpKeY0IhxaFQCLcB/s1600/2.jpg)

# Credits
core developer : X47 ;
user experience : Mr. X ;
security test : dewmonic, tobasec ;

# Note

this project is no longer being maintained

