
<h1>ABOUT ME</h1>
<pre>
[ABOUT]
DARKNET unrestricted information, chat, social network, 
forum, file sharing, leaderboard CTF, dedicated for hacker, programmer, 
webmaster, database administator, network administrator, game maker, gamer, 
with no need registration , ne need email verification, no need real identity. 
Because information is free !

platfrom berbasis web yang berfungsi sebagai simple social networking, chatting,
file sharing, forum, dan juga real game leaderboard untuk para hacker, programmer,
web admin, database admin, gamer, game maker. dan fitur akan terus diupdate sesuai kebutuhan.
kelebihan dari website ini adalah kerahasiaan, sehingga kita dapat berdiskusi lebih dalam
mengenai internet ataupun perangkat lunak untuk menggali informasi yang dianggap tabu (zona abu-abu)
yang dapat kita gunakan untuk menambah ilmu pengetahuan dan keperluan penelitian.




[CONTACT]
anda dapat menghubungi admin melalui menu inbox dalam game.



[RULES]

DILARANG KERAS !!!

-SARA
-porn
-scam
-promosi
-spam
-politik
-mengorganisir tindakan yang merugikan negara indonesia
-kita disini bertanggung jawab ikut dalam pertahanan cyber indonesia dari serangan luar
-mengorganisir tindakan yang merugikan orang awam /gaptek
-transaksi melibatkan keuangan, jika nekat resiko tanggung sendiri. karena web ini tidak dirancang untuk
perlindungan transaksi keuangan secara aman


mari junjung tinggi kerahasiaan identitas dan kebebasan informasi yang bertanggung jawab





[PRIVASI]
kami tidak pernah meminta identitas asli seperti nama, alamat, password dsb. 
password yang disimpan dalam database berbentuk hash yang telah dimodifikasi sehingga tidak mudah untuk diretas.
sedangkan percakapan inbox menggunakan enkripsi salt custom sehingga hanya lawan bicara yang tahu apa isi
pesan tersebut. dan pesan inbox akan otomatis terhapus setelah halaman dimuat.





[COOKIE]
web ini menggunakan cookie dan layanan pihak ketiga seperti google analytic untuk memantau traffic
dan pertimbangan pengembangan web. juga ada iklan yang sudah diseleksi sehingga tidak mengganggu kenyamanan user.
iklan ini dipakai untuk biaya operasional,perawatan dan pengembangan.





[LEGAL]
admin tidak bertanggung jawab atas isi percakapan maupun penyalahgunaan 
web ini untuk keperluan penipuan, 
peretasan dan kejahatan cyber lainnya. 
admin tidak terlibat dalam peretasan di dunia nyata dan tidak berafiliasi dengan kelompok hacker manapun.
semua konten dari user untuk user menjadi tanggung jawab user itu sendiri.



[TOS]
admin tidak bertanggung jawab sepenuhnya atas database user yang tersimpan seperti username, exp ataupun score
yang tersimpan menjadi hak admin. 
admin berhak merubah, menghapus, database tanpa persetujuan user. 
admin tidak mempunyai kewajiban penuh
untuk memastikan website selalu dalam keadaan online. misal suatu saat terjadi crash, bencana alam, listrik padam, 
kerusakan hardware
, gagal backup, blokir pemerintah/ISP, user diharap untuk memaklumi. 
Dengan mengunduh atau mendapat informasi dari web ini admin tidak memberikan garansi atau jaminan bahwa informasi tersebut adalah valid,
atau perangkkat lunak adalah bersih dari virus. setiap mengunduh file user bertanggung jawab atas tindakannya sendiri, resiko infeksi virus dan malware menjadi tanggung jawab user itu sendiri.
Halaman about ini akan diperbarui tanpa adanya pemberitahuan, user diharuskan untuk selalu memantau perubahan
halaman ini.


Dengan mengakses web ini user dianggap telah membaca dan setuju dengan syarat ketentuan ini.


</pre>
